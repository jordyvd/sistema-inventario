<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv='X-UA-Compatible' content='IE=8'>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php if(Auth::user()): ?>
      <title><?php echo e(Auth::user()->sucursal); ?> - sistema de administración</title>
      <meta name="user_name" content="<?php echo e(Auth::user()->name); ?>">
      <meta name="user_sucursal" content="<?php echo e(Auth::user()->sucursal); ?>">
      <meta name="user_rol" content="<?php echo e(Auth::user()->rol); ?>">
      <meta name="user_id" content="<?php echo e(Auth::user()->id); ?>">
      <meta name="user_id_sucursal" content="<?php echo e(Auth::user()->id_sucursal); ?>">
      <?php $__currentLoopData = $permisos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <meta name="traslados" content="<?php echo e($info->traslados); ?>">
        <meta name="ventas" content="<?php echo e($info->ventas); ?>">
        <meta name="sucursal_ventas" content="<?php echo e($info->sucursal_ventas); ?>">
        <meta name="reportes" content="<?php echo e($info->reportes); ?>">
        <meta name="ganancias" content="<?php echo e($info->ganancias); ?>">
        <meta name="clientes" content="<?php echo e($info->clientes); ?>">
        <meta name="mantenimiento" content="<?php echo e($info->mantenimiento); ?>">
        <meta name="agregar_modif_mante" content="<?php echo e($info->agregar_modif_mante); ?>">
        <meta name="almacen" content="<?php echo e($info->almacen); ?>">
        <meta name="permisos" content="<?php echo e($info->permisos); ?>">
        <meta name="compras" content="<?php echo e($info->compras); ?>">
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
    <title>sistema de administración</title>
    <?php endif; ?>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/util.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/pace.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/menu.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/estilos.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/bienvenida.css')); ?>">
    <link rel="shortcut icon" type="image/x-icon" href="images/compra.ico"/>
</head>
  <body>
    <?php if(Auth::user()): ?>
       <div id="app">
       <menu_sistema></menu_sistema>
       </div>
    <?php else: ?>
       <div id="app">
       <login_user></login_user>
       </div>
    <?php endif; ?>
    <!-- importante -->
       <script src="<?php echo e(asset('js/app.js')); ?>"></script>
       <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
       <script src="<?php echo e(asset('js/main.js')); ?>"></script>
       <script src="<?php echo e(asset('js/poper.js')); ?>"></script>
       <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
       <script src="<?php echo e(asset('js/funciones.js')); ?>"></script>
       <script src="<?php echo e(asset('js/pace.min.js')); ?>"></script>
  </body>
</html><?php /**PATH D:\sistema_inventario_2020\sistema_inventario\resources\views/index.blade.php ENDPATH**/ ?>