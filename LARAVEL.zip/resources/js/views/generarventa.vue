<template>
  <div>
    <div class="acciones" v-if="user_ventas < 1">
      <notpermiso />
    </div>
    <div class="container" v-else>
      <br />
      <div class="card">
        <div class="card-header">
          <b v-if="nrof.length < 1"
            ><i class="fas fa-edit"></i> agregar venta (calculando...)</b
          >
          <b v-else
            ><i class="fas fa-edit"></i> agregar venta (F00{{
              user_id_sucursal
            }}-{{ producto.numfactura }})</b
          >
          &nbsp;
          <input
            type="radio"
            id="barra_r"
            v-model="condicion"
            name="busqueda"
            value="barra"
          />
          <label for="barra_r">barra</label>
          <input
            type="radio"
            v-model="condicion"
            id="codigo_r"
            name="busqueda"
            value="codigo"
          />
          <label for="codigo_r">codigo</label>
        </div>
        <div class="card-body">
          <!-- <div class="centrar border">
            <div class="col-md-3 mb-3 my-3">
              <select class="custom-select" v-model="producto.estado">
                <option value disabled>tipo de venta...</option>
                <option value="1">boleta</option>
                <option value="tarjeta">factura</option>
                <option value="trasnferencia">tiked</option>
              </select>
            </div>
          </div> -->
          <div class="form-row centrar">
            <div class="col-md-3 mb-3">
              <label>codigo de barra</label>
              <form @submit.prevent="escanear">
                <input
                  type="search"
                  class="form-control"
                  v-model="codigo_barra"
                />
              </form>
            </div>
            <!-- <div class="col-md-1 mb-3">
                <label>Búsqueda</label>
                <select class="custom-select" v-model="producto.estado">
                  <option value="trasnferencia">transferencia</option>
                  <option value="yape">yape</option>
                  <option value="0">credito</option>
                </select>
              </div> -->
            <div class="col-md-2 mb-3">
              <label>ruc o dni</label>
              <form @submit.prevent="buscarcliente">
                <input
                  type="search"
                  class="form-control"
                  v-model="producto.ruc_dni"
                />
              </form>
            </div>
            <div class="col-md-2 mb-3">
              <label>nombre</label>
              <input
                type="text"
                class="form-control"
                v-model="producto.nom_cliente"
              />
            </div>
            <div class="col-md-2 mb-3">
              <label> documento </label>
              <select class="custom-select" v-model="tipo_v">
                <option value disabled>seleccionar...</option>
                <option value="ticked">ticked</option>
                <option value="boleta">boleta</option>
                <option value="factura">factura</option>
              </select>
            </div>
          </div>
          <form @submit.prevent="generar_venta">
            <div class="form-row centrar">
              <div class="col-md-3 mb-3">
                <label> condición</label>
                <select class="custom-select" v-model="producto.estado">
                  <option value disabled>seleccionar...</option>
                  <option value="1">efectivo</option>
                  <option value="tarjeta">tarjeta</option>
                  <option value="trasnferencia">transferencia</option>
                  <option value="yape">yape</option>
                  <option value="0">credito</option>
                  <option value="0">cancelado</option>
                </select>
              </div>
              <div class="col-md-3 mb-3">
                <label>total a pagar</label>
                <input
                  type="text"
                  class="form-control"
                  :value="total_pagar.toFixed(2)"
                  disabled
                />
              </div>
              <div class="col-md-3 mb-3">
                <label for="" class="text-white">finalizar</label>
                <button
                  type="submit"
                  v-if="!spinner_table"
                  class="form-control btn btn-primary"
                >
                  <i class="fas fa-piggy-bank"></i> guardar
                </button>
                <button
                  v-else
                  class="form-control btn btn-primary"
                  type="button"
                  disabled
                >
                  <span
                    class="spinner-grow spinner-grow-sm"
                    role="status"
                    aria-hidden="true"
                  ></span>
                  cargando...
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
      <!-- **** DATOS ***** -->
      <br />
      <div class="card">
        <div class="card-header">
          <b><i class="fas fa-list"></i> lista de productos</b>
        </div>
        <div class="card-body">
          <div class="alert centrar" v-if="agregados.length < 1">
            no hay productos agregados
          </div>
          <div v-else class="table-scroll">
            <div v-if="spinner_table" class="centrar">cargando...</div>
            <table class="table" v-else>
              <thead>
                <tr>
                  <th scope="col">#</th>
                  <th scope="col">producto</th>
                  <th scope="col">marca</th>
                  <th scope="col">precio venta</th>
                  <!-- <th scope="col">precio compra</th> -->
                  <th scope="col">cantidad</th>
                  <th scope="col">descuento</th>
                  <th scope="col">importe</th>
                  <th scope="col">imagen</th>
                </tr>
              </thead>
              <tbody v-for="(item, index) in agregados" :key="index">
                <tr>
                  <th scope="row">{{ index + 1 }}</th>
                  <td>
                    {{ item.producto }}
                    <button
                      class="text-dark"
                      @click="eliminaragregado(index)"
                      title="eliminar"
                    >
                      <i class="far fa-trash-alt"></i>
                    </button>
                  </td>
                  <td>{{ item.marca }}</td>
                  <td>{{ parseFloat(item.precio).toFixed(2) }}</td>
                  <!-- <td>{{ parseFloat(item.precio_compra).toFixed(2) }}</td> -->
                  <td>{{ item.cantidad }}</td>
                  <td>{{ parseFloat(item.descuento).toFixed(2) }}</td>
                  <td>
                    {{
                      (
                        parseFloat(item.precio) * parseFloat(item.cantidad) -
                        parseFloat(item.descuento)
                      ).toFixed(2)
                    }}
                  </td>
                  <td>
                    <button
                      data-toggle="modal"
                      data-target="#modalimagen"
                      @click="imagen(item)"
                    >
                      <i class="fas fa-images"></i>
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <!-- ************* modal scanner ************** -->
      <!-- Button trigger modal -->
      <button
        type="button"
        id="modalBarra"
        data-toggle="modal"
        data-target="#exampleModal"
      ></button>

      <!-- Modal -->
      <div
        class="modal fade"
        id="exampleModal"
        tabindex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div class="modal-dialog">
          <div class="modal-content border-modal">
            <div class="modal-header bg-primary">
              <h5 class="modal-title text-system" id="exampleModalLabel">
                agregar venta
              </h5>
              <button
                type="button"
                class="close"
                id="cerrar_modal"
                data-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <!-- ********* FORMULARIO *********** -->
              <div
                class="spinner-border text-primary"
                v-if="spinner_modal"
                role="status"
              >
                <span class="sr-only">Loading...</span>
              </div>
              <form class="formularios_sistema" @submit.prevent="agregar_prod">
                <div class="form-row align-items-center centrar">
                  <div class="col-auto">
                    <input type="text" v-model="barra_result" />
                    <small class="form-text text-muted">producto</small>
                    <div class="input-group mb-2">
                      <div class="input-group-prepend">
                        <div class="input-group-text">
                          <i class="fab fa-product-hunt"></i>
                        </div>
                      </div>
                      <input
                        type="text"
                        class="form-control"
                        v-model="producto.nompro"
                        disabled
                      />
                    </div>
                  </div>
                  <div class="col-auto">
                    <small class="form-text text-muted">precio</small>
                    <div class="input-group mb-2">
                      <div class="input-group-prepend">
                        <div class="input-group-text">
                          <i class="fas fa-credit-card"></i>
                        </div>
                      </div>
                      <input
                        type="text"
                        class="form-control solonumero"
                        v-model="producto.precio"
                        disabled
                      />
                    </div>
                  </div>
                  <div class="col-auto">
                    <small class="form-text text-muted">marca</small>
                    <div class="input-group mb-2">
                      <div class="input-group-prepend">
                        <div class="input-group-text">
                          <i class="fas fa-truck-loading"></i>
                        </div>
                      </div>
                      <input
                        type="text"
                        class="form-control"
                        v-model="producto.marca"
                        disabled
                      />
                    </div>
                  </div>
                  <div class="col-auto">
                    <small class="form-text text-muted">stock</small>
                    <div class="input-group mb-2">
                      <div class="input-group-prepend">
                        <div class="input-group-text">
                          <i class="fas fa-cubes"></i>
                        </div>
                      </div>
                      <input
                        type="text"
                        class="form-control"
                        v-model="producto.stock"
                        disabled
                      />
                    </div>
                  </div>
                  <div class="col-auto">
                    <small class="form-text text-muted">cantidad</small>
                    <div class="input-group mb-2">
                      <div class="input-group-prepend">
                        <div class="input-group-text">
                          <i class="fas fa-align-left"></i>
                        </div>
                      </div>
                      <input
                        type="text"
                        class="form-control solonumero"
                        placeholder="Cantidad"
                        v-model="producto.cantidad"
                      />
                    </div>
                  </div>
                  <div class="col-auto">
                    <small id="codigo_barra" class="form-text text-muted"
                      >descuento</small
                    >
                    <div class="input-group mb-2">
                      <div class="input-group-prepend">
                        <div class="input-group-text">
                          <i class="fas fa-tags"></i>
                        </div>
                      </div>
                      <input
                        type="number"
                        class="form-control solonumero"
                        placeholder="Descuento"
                        v-model="producto.descuento"
                      />
                    </div>
                  </div>
                </div>
                <div class="centrar">
                  <button class="btn btn-primary" type="submit">agregar</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- ****** MODAL IMAGEN ****** -->
    <div
      class="modal fade"
      id="modalimagen"
      tabindex="-1"
      aria-labelledby="exampleModalLabel"
      aria-hidden="true"
    >
      <div class="modal-dialog">
        <div class="modal-content border-modal">
          <div class="modal-header">
            <h5 class="modal-title text-system">{{ producto.nompro }}</h5>
            <button
              type="button"
              class="close"
              data-dismiss="modal"
              aria-label="Close"
            >
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <img
              class="img-product"
              :src="'images/productos/' + producto.img"
              alt=""
              width="400"
            />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      tipo_v: "",
      producto: {
        id: "",
        ruc_dni: "",
        nom_cliente: "",
        nompro: "",
        precio: "",
        precio_compra: "",
        marca: "",
        stock: "",
        cantidad: "",
        descuento: "0",
        numfactura: "",
        cantidad: "",
        estado: "",
        img: "default.png",
      },
      condicion: "barra",
      barra_result: "",
      spinner_modal: false,
      codigo_barra: "",
      productos: [],
      cliente: [],
      agregados: [],
      nrof: [],
      spinner_table: false,
    };
  },
  created() {
    let agregadosDB = JSON.parse(localStorage.getItem("agregado_venta"));
    if (agregadosDB === null) {
      this.agregados = [];
    } else {
      this.agregados = agregadosDB;
    }
    this.generar_nuevo_numer_f();
  },
  methods: {
    escanear() {
      this.spinner_modal = true;
      document.getElementById("modalBarra").click();
      let url_scnn =
        "/api/escanearventa/" +
        this.condicion +
        "/" +
        this.codigo_barra +
        "/" +
        this.user_sucursal;
      axios
        .get(url_scnn)
        .then((res) => {
          this.productos = res.data;
          this.barra_result = this.productos.barra;
          this.producto.nompro = this.productos.nompro;
          this.producto.precio = this.productos.precio_venta;
          this.producto.precio_compra = this.productos.precio;
          this.producto.marca = this.productos.marca;
          this.producto.stock = this.productos.stock_almacen;
          this.producto.img = this.productos.url_imagen;
          this.spinner_modal = false;
        })
        .catch((error) => {
          swal("ERROR", "comprobar conexión", "info");
        });
    },
    buscarcliente() {
      if (this.producto.ruc_dni.trim() === "") {
      } else {
        let url = "/api/buscarclienteventa/" + this.producto.ruc_dni;
        axios.get(url).then((res) => {
          this.cliente = res.data;
          this.producto.nom_cliente = this.cliente.nombre;
        });
      }
    },
    agregar_prod() {
      if (
        this.producto.nompro.trim() === "" ||
        this.codigo_barra.trim() === "" ||
        this.producto.cantidad.trim() === "" ||
        this.producto.descuento.trim() === ""
      ) {
        Vue.$toast.error("completar todos los campos");
      } else {
        if (this.agregados.length > 11) {
          Vue.$toast.error("llegó al límite");
        } else {
          this.agregados.push({
            barra: this.barra_result,
            producto: this.producto.nompro,
            marca: this.producto.marca,
            precio: this.producto.precio,
            precio_compra: this.producto.precio_compra,
            cantidad: this.producto.cantidad,
            descuento: this.producto.descuento,
            url_imagen: this.producto.img,
          });
          localStorage.setItem(
            "agregado_venta",
            JSON.stringify(this.agregados)
          );
          document.getElementById("cerrar_modal").click();
          this.vaciar_form();
        }
      }
    },
    eliminaragregado(index) {
      swal({
        text: "¿eliminar?",
        icon: "error",
        buttons: ["no", "sí"],
        dangerMode: true,
      }).then((willDelete) => {
        if (willDelete) {
          this.agregados.splice(index, 1);
          localStorage.setItem(
            "agregado_venta",
            JSON.stringify(this.agregados)
          );
          Vue.$toast.info("se eliminó con éxito");
        }
      });
    },
    generar_nuevo_numer_f() {
      this.spinner2 = true;
      let url = "/api/nrof/" + this.user_sucursal;
      axios
        .get(url)
        .then((res) => {
          if (res.data === "") {
            this.nrof = "0";
            this.nrof = parseFloat(this.nrof) + 1;
            this.nrof = zeroPad(this.nrof, 9);
            this.producto.numfactura = this.nrof;
          } else {
            this.nrof = res.data;
            this.nrof = parseFloat(this.nrof) + 1;
            this.nrof = zeroPad(this.nrof, 9);
            this.producto.numfactura = this.nrof;
          }
        })
        .catch((error) => {
          location.reload();
        });
    },
    generar_venta() {
      const params = {
        nrof: this.producto.numfactura,
        estado: this.producto.estado,
        tipo_v: this.tipo_v,
        total_v: this.total_pagar,
        total_ganancia: this.total_pagar - this.total_precio_compra,
        ruc_dni: this.producto.ruc_dni,
        nom_cliente: this.producto.nom_cliente,
        sucursal: this.user_sucursal,
        cod_sucursal:
          "F00" + this.user_id_sucursal + "-" + this.producto.numfactura,
        usuario: this.user_name,
      };
      swal({
        text: "¿estás seguro?",
        icon: "error",
        buttons: ["no", "sí"],
        dangerMode: true,
      }).then((willDelete) => {
        if (willDelete) {
          // ***** validar ******
          if (this.producto.estado.trim() === "" || this.tipo_v.trim() === "") {
            Vue.$toast.error("completar todos los campos");
          } else {
            this.spinner_table = true;
            axios
              .post("/generar_venta", params)
              .then((res) => {
                this.agregarventa_detalles();
                this.generar_nuevo_numer_f();
                this.vaciar_datos();
              })
              .catch((error) => {
                this.spinner_table = false;
                swal("ERROR", "comprobar conexión", "info");
              });
          }
        }
      });
    },
    imagen(item) {
      this.producto.img = item.url_imagen;
      this.producto.nompro = item.producto;
    },
    vaciar_form() {
      this.$data.producto.cantidad = ""; // vaciar campo
      this.$data.producto.descuento = "0"; // vaciar campo
      this.$data.producto.nompro = ""; // vaciar campo
      this.$data.producto.marca = ""; // vaciar campo
      this.$data.producto.stock = ""; // vaciar campo
      this.$data.producto.precio = ""; // vaciar campo
      this.$data.codigo_barra = ""; // vaciar campo
    },
    vaciar_datos() {
      this.$data.producto.ruc_dni = "";
      this.$data.producto.nom_cliente = "";
    },
    eliminar_productos(index) {
      this.agregados.splice(index, 1);
      localStorage.setItem("agregado_venta", JSON.stringify(this.agregados));
      this.spinner_table = false;
    },
    agregarventa_detalles() {
      let i = 0;
      for (i = 0; i < this.agregados.length; i++) {
        const params = {
          sucursal: this.user_sucursal,
          nrof: "F00" + this.user_id_sucursal + "-" + this.producto.numfactura,
          barra: this.agregados[i].barra,
          precio: this.agregados[i].precio,
          cantidad: this.agregados[i].cantidad,
          descuento: this.agregados[i].descuento,
        };
        if (this.agregados[6]) {
          Vue.$toast.info("espere...");
          axios.post("/detalle_venta", params).then((res) => {
            this.eliminar_productos(this.agregados[i]);
            Vue.$toast.success("venta guardada");
          });
        } else {
          axios.post("/detalle_venta", params).then((res) => {
            this.eliminar_productos(this.agregados[i]);
            Vue.$toast.success("venta guardada");
          });
        }
      }
    },
  },
  computed: {
    total_pagar() {
      return this.agregados.reduce((total, item) => {
        return total + item.precio * item.cantidad - item.descuento;
      }, 0);
    },
    total_precio_compra() {
      return this.agregados.reduce((total, item) => {
        return total + item.precio_compra * item.cantidad - item.descuento;
      }, 0);
    },
    total_ganancia() {
      return this.agregados.reduce((total, item) => {
        return total + this.total_pagar - this.total_precio_compra;
      }, 0);
    },
  },
};
</script>