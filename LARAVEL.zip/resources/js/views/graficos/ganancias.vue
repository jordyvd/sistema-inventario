<template>
  <div class="container">
    <div v-if="user_ganancias>0">
      <grafico-ganancia></grafico-ganancia>
    </div>
    <div v-else class="pdd-30">
      <notpermiso></notpermiso>
    </div>
  </div>
</template>