<template>
  <div>
    <div v-if="user_ventas < 1">
      <notpermiso />
    </div>
    <div class="row" v-else>
      <div class="carga-total" v-if="carga_factura">
        <div
          class="spinner-border"
          style="width: 3rem; height: 3rem"
          role="status"
        >
          <span class="sr-only">Loading...</span>
        </div>
      </div>
      <div class="container">
        <!-- Modal -->
        <div
          class="modal fade"
          id="exampleModal"
          tabindex="-1"
          aria-labelledby="exampleModalLabel"
          aria-hidden="true"
        >
          <div class="modal-dialog modal-lg">
            <div class="modal-content border-modal">
              <div class="modal-header bg-system">
                <h5 class="modal-title text-system" id="exampleModalLabel">
                  {{ nrof }}({{ total }})
                </h5>
                <button
                  type="button"
                  class="close"
                  data-dismiss="modal"
                  aria-label="Close"
                >
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <!-- *** DATELLES *** -->
                <div v-if="spinner_details" class="centrar">
                  <p>cargando...</p>
                </div>
                <!-- <span class="sr-only">Loading...</span> -->
                <!-- </div> -->
                <table class="table table-bordered" v-else>
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Producto / descripción</th>
                      <th scope="col">Precio</th>
                      <th scope="col">Cantidad</th>
                      <th scope="col">Descuento</th>
                      <th scope="col">Importe</th>
                    </tr>
                  </thead>
                  <tbody v-for="(item, index) in detalles" :key="index">
                    <tr>
                      <th scope="row">{{ index + 1 }}</th>
                      <td>{{ item.nompro }}</td>
                      <td>{{ parseFloat(item.precio).toFixed(2) }}</td>
                      <td>{{ item.cantidad }}</td>
                      <td>{{ parseFloat(item.descuento).toFixed(2) }}</td>
                      <td>
                        {{
                          (
                            parseFloat(item.precio) *
                              parseFloat(item.cantidad) -
                            parseFloat(item.descuento)
                          ).toFixed(2)
                        }}
                      </td>
                    </tr>
                  </tbody>
                </table>
                <!-- *** FIN DETALLES *** -->
              </div>
            </div>
          </div>
        </div>
        <!-- ** modal ** -->
        <div class="card-header">
          <input
            type="search"
            placeholder="Buscar número"
            class="input-search"
            v-model="search"
          />
          <button class="button" @click="buscar">
            <i class="fas fa-search"></i> Buscar
          </button>
          <button class="button" @click="refrescar">
            <i class="fas fa-redo-alt"></i> refrescar
          </button>
          <input
            type="date"
            id="input-date"
            class="input-search"
            v-model="fechadesde"
            min="2020-01-01"
          />
          <input
            type="date"
            @change="listar"
            id="input-date"
            class="input-search"
            v-model="fecha"
            min="2020-01-01"
          />
          <select
            class="input-search"
            v-if="sucursal_ventas > 0"
            @change="listar"
            style="padding: 14px 2px"
            v-model="sucursal_seleccionado"
          >
            <option value="" disabled>seleccionar...</option>
            <option
              v-for="(item, index) in sucursal"
              :key="index"
              :value="item.nombre"
            >
              {{ item.nombre }}
            </option>
          </select>
          creditos({{ pagination.total }})
        </div>
        <!-- **** LOADING **** -->
        <div v-if="loading_table" class="centrar">
          <p>cargando...</p>
        </div>
        <div v-else>
          <div class="alert centrar" v-if="ventas.length < 1">
            no hay registros
          </div>
          <div class="table-scroll" v-else>
            <table class="table">
              <thead>
                <tr>
                  <th scope="col">#</th>
                  <th scope="col">nro</th>
                  <th scope="col">cliente</th>
                  <th scope="col">acumulado</th>
                  <th scope="col">total a pagar</th>
                  <th scope="col">pagado</th>
                  <th scope="col">documento</th>
                  <th scope="col">fecha</th>
                  <th scope="col">editar</th>
                  <th scope="col">imprimir</th>
                  <th scope="col">anular</th>
                </tr>
              </thead>
              <tbody v-for="(item, index) in ventas" :key="index">
                <tr>
                  <th scope="row">{{ index + 1 }}</th>
                  <td>
                    {{ item.cod_sucursal }}
                    <button
                      data-toggle="modal"
                      @click="detalle_venta(item)"
                      data-target="#exampleModal"
                    >
                      <i class="fas fa-eye"></i>
                    </button>
                  </td>
                  <td v-if="item.nombre_cliente === null" class="text-danger">
                    <i class="fas fa-user-times"></i>
                  </td>
                  <td v-else>{{ item.nombre_cliente }}</td>
                  <td>
                    {{ parseFloat(item.estado_pago).toFixed(2) }}
                    <button
                      class="text-dark"
                      @click="estado_pago_edit(item)"
                      title="sumar monto"
                    >
                      <i class="fas fa-piggy-bank"></i>
                    </button>
                  </td>
                  <td>
                    {{ parseFloat(item.total_v).toFixed(2) }}({{
                      (
                        parseFloat(item.total_v) - parseFloat(item.estado_pago)
                      ).toFixed(2)
                    }})
                  </td>
                  <td v-if="item.estado > 0" class="text-success">
                    <i class="fas fa-check-circle"></i>
                  </td>
                  <td v-else>
                    <button class="text-danger" @click="cambiarestado(item)">
                      <i class="fas fa-times-circle"></i>
                    </button>
                  </td>
                  <td>
                    {{ item.tipo_v }}
                  </td>
                  <td>{{ item.fecha }}</td>
                  <td>
                    <button
                      class="text-dark"
                      @click="editarmonto_acumulado(item)"
                    >
                      <i class="fas fa-edit"></i>
                    </button>
                  </td>
                  <td v-if="item.nombre_cliente === null" class="text-danger">
                    <i class="fas fa-times-circle"></i>
                  </td>
                  <td v-else>
                    <button class="text-primary" @click="factura_details(item)">
                      <i class="fa fa-print"></i>
                    </button>
                  </td>
                  <td>
                    <button
                      class="text-danger"
                      @click="anular_factura_items(item, index)"
                    >
                      <i class="fas fa-ban"></i>
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          <!-- ******* PAGINACION ********* -->
          <nav>
            <ul class="pagination">
              <li v-if="pagination.current_page > 1" class="page-item">
                <a
                  href="#"
                  @click.prevent="changePage(pagination.current_page - 1)"
                >
                  <span>
                    <b>Atras</b>
                  </span>
                </a>
              </li>
              <li
                class="page-item"
                v-for="(page, index) in pagesNumber"
                v-bind:class="[page == isActived ? 'active_pagination' : '']"
                :key="index"
              >
                <a href @click.prevent="changePage(page)">
                  <b>{{ page }}</b>
                </a>
              </li>
              <li
                class="page-item"
                v-if="pagination.current_page < pagination.last_page"
              >
                <a
                  href="#"
                  @click.prevent="changePage(pagination.current_page + 1)"
                >
                  <span>
                    <b>Siguiente</b>
                  </span>
                </a>
              </li>
            </ul>
          </nav>
        </div>
      </div>
      <!-- ********* IMPRIMIR FACTURA ********** -->
      <!-- Modal -->
      <div
        class="modal fade"
        id="FacturaModal"
        tabindex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
              <button
                type="button"
                class="close"
                data-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <button @click="print">pe</button>
              <div id="printMe" style="display: none">
                <div class="container">
                  <div class="row">
                    <div class="col-sm" style="width: 400px; left: -13.6%">
                      <img src="images/GIOMAR.jpg" width="350" height="150" />
                    </div>
                    <div class="col-sm">
                      <b style="font-size: 31px">GIOMAR SPORT</b>
                      <p>Direccion legal: Morales Bermudez 342, Huaral 15201</p>
                      <p>telefono: 955 347 316</p>
                      <p>fecha: {{ datos_impresion.fecha }}</p>
                    </div>
                    <div
                      class="col-sm border border-dark rounded"
                      style="left: 14%"
                    >
                      <br />
                      <p
                        style="
                          display: flex;
                          align-items: center;
                          justify-content: center;
                        "
                      >
                        R.U.C. 10405163131
                      </p>
                      <p
                        style="
                          display: flex;
                          align-items: center;
                          justify-content: center;
                        "
                      >
                        {{ datos_impresion.tipo }} DE VENTA
                      </p>
                      <p
                        style="
                          display: flex;
                          align-items: center;
                          justify-content: center;
                        "
                      >
                        N° {{ nrof }}
                      </p>
                    </div>
                  </div>
                </div>
                <div
                  class="rounded border border-dark"
                  style="
                    margin: 20px 0 !important;
                    height: 1000px;
                    text-transform: uppercase;
                  "
                >
                  <div
                    class="row"
                    style="padding: 10px 20px; border-bottom: 1px solid black"
                  >
                    <div class="col-6">
                      <p>SEÑOR(ES) DE COMPRA: {{ nombre_cliente }}</p>
                      <p>
                        {{ datos_impresion.tipo }} DEL CLIENTE:
                        {{ ruc_dni_cli }}
                      </p>
                      <p>direccion: {{ cliente.direccion }}</p>
                      <p>telefono: {{ cliente.telefono }}</p>
                    </div>
                    <div class="col-6" style="left: 22% !important">
                      <p>ESTADO DE PAGO: credito</p>
                      <p>SUCURSAL DE COMPRA: {{ user_sucursal }}</p>
                      <p>VENDEDOR ENCARGADO: {{ datos_impresion.vendedor }}</p>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-12" style="padding: 10px 50px !important">
                      <table class="table">
                        <thead>
                          <tr>
                            <th scope="col">#</th>
                            <th scope="col">Producto / descripción</th>
                            <th scope="col">Precio</th>
                            <th scope="col">Cantidad</th>
                            <th scope="col">Descuento</th>
                            <th scope="col">Importe</th>
                          </tr>
                        </thead>
                        <tbody v-for="(item, index) in detalles" :key="index">
                          <tr>
                            <th scope="row">{{ index + 1 }}</th>
                            <td>{{ item.nompro }}</td>
                            <td>{{ parseFloat(item.precio).toFixed(2) }}</td>
                            <td>{{ item.cantidad }}</td>
                            <td>{{ parseFloat(item.descuento).toFixed(2) }}</td>
                            <td>
                              {{
                                (
                                  parseFloat(item.precio) *
                                    parseFloat(item.cantidad) -
                                  parseFloat(item.descuento)
                                ).toFixed(2)
                              }}
                            </td>
                            <input type="text" v-model="da_factura" hidden />
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
                <div class="container">
                  <div class="row" style="padding: 30px 0px">
                    <div class="col-sm">
                      <p style="border-top: 1px solid black">recibido</p>
                    </div>
                    <div class="col-sm">
                      <p style="border-top: 1px solid black">despachado</p>
                    </div>
                    <div class="col-sm" style="left: 15%">
                      <ul class="list-group">
                        <li
                          class="list-group-item"
                          style="border: 1px solid black"
                        >
                          Subtotal: S/.{{ parseFloat(total_venta).toFixed(2) }}
                        </li>
                        <li
                          class="list-group-item"
                          style="border: 1px solid black"
                        >
                          Descuento: S/.{{
                            parseFloat(total_descuento).toFixed(2)
                          }}
                        </li>
                        <li
                          class="list-group-item"
                          style="border: 1px solid black"
                        >
                          Total: S/.{{ parseFloat(total_general).toFixed(2) }}
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
              <!-- OUTPUT -->
            </div>
          </div>
        </div>
      </div>
      <!-- ***** FIN IMPRIMIR ****** -->
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      ventas: [],
      search: "",
      detalles: [],
      nrof: "",
      total: "",
      cliente_ruc: "",
      cliente_dni: "",
      sucursal_seleccionado: "",
      nombre_cliente: "",
      spinner: false,
      fecha: "1",
      fechadesde: "1",
      loading_table: false,
      spinner_details: false,
      carga_factura: false,
      da_factura: "",
      cliente_detalle: [],
      sucursal: [],
      cliente: {
        telefono: "",
        direccion: "",
      },
      datos_impresion: {
        estado: "",
        tipo: "",
        vendedor: "",
        sucursal: "",
        fecha: "",
      },
      ruc_dni_cli: "",
    };
  },
  created() {
    this.listar();
    axios.get("/api/listsucursal").then((res) => {
      this.sucursal = res.data.sucursal.data;
    });
  },
  methods: {
    listar(page) {
      this.loading_table = true;
      if (this.sucursal_seleccionado === "") {
        this.sucursal_seleccionado = this.user_sucursal;
      }
      let url =
        "/api/listcreditos/" +
        this.sucursal_seleccionado +
        "/" +
        this.fecha +
        "/" +
        this.fechadesde +
        "?page=" +
        page;
      axios.get(url).then((res) => {
        this.ventas = res.data.ventas.data;
        this.pagination = res.data.paginate;
        this.loading_table = false;
      });
    },
    refrescar() {
      this.loading_table = true;
      this.$data.fecha = "1";
      this.$data.fechadesde = "1";
      this.$data.search = "";
      this.listar();
      document.getElementById("input-date").innerHTML = "";
    },
    editarmonto_acumulado(item) {
      swal("modificar monto acumulado:", {
        content: "input",
      }).then((value) => {
        if (value > 0) {
          Vue.$toast.info("actualizando datos...");
          const params = { acumulado: value };
          axios.post("/modificaracumulado/" + item.id, params).then((res) => {
            this.listar();
          });
        } else {
          Vue.$toast.error("monto incorrecto");
        }
      });
    },
    detalle_venta(item) {
      this.spinner_details = true;
      this.nrof = item.cod_sucursal;
      this.total = item.total_v;
      let url = `/api/listdetalles/${item.cod_sucursal}/${this.user_sucursal}`;
      axios.get(url).then((res) => {
        this.detalles = res.data;
        this.spinner_details = false;
      });
    },
    anular_factura(item, index) {
      let url =
        "/anularfactura/" +
        item.id +
        "/" +
        item.cod_sucursal +
        "/" +
        this.user_sucursal;
      axios.get(url).then((res) => {
        this.ventas.splice(index, 1);
        this.listar();
      });
    },
    changePage(page) {
      this.pagination.current_page = page;
      this.listar(page);
    },
    print() {
      // Pass the element id here
      this.$htmlToPaper("printMe");
    },
    factura_details(item) {
      let url = `/api/listdetalles/${item.cod_sucursal}/${this.user_sucursal}`;
      axios
        .get(url)
        .then((res) => {
          this.detalles = res.data;
          this.carga_factura = true;
          this.nrof = item.cod_sucursal;
          this.total = item.total_v;
          this.datos_impresion.vendedor = item.usuario;
          this.datos_impresion.fecha = item.fecha;
          this.nombre_cliente = item.nombre_cliente;
          this.ruc_dni_cli = item.ruc_dni_v;
          let ruc_dni = item.ruc_dni_v;
          if (ruc_dni.length > 9) {
            this.$data.datos_impresion.tipo = "FACTURA";
          } else {
            this.datos_impresion.tipo = "BOLETA";
          }
          let url = `/api/listdetalles/${item.cod_sucursal}/${this.user_sucursal}`;
          axios.get(url).then((res) => {
            this.detalles = res.data;
          });
          let urlclie = `/api/buscarclienteventa/${this.ruc_dni_cli}`;
          axios.get(urlclie).then((res) => {
            this.cliente_detalle = res.data;
            this.cliente.direccion = this.cliente_detalle.direccion;
            this.cliente.telefono = this.cliente_detalle.telefono;
          });
          axios.get(urlclie).then((res) => {
            this.cliente_detalle = res.data;
            this.cliente.direccion = this.cliente_detalle.direccion;
            this.cliente.telefono = this.cliente_detalle.telefono;
            this.carga_factura = false;
            this.print();
          });
        })
        .catch((error) => {
          swal("ERROR", "comprobar conexión", "info");
        });
    },
    cambiarestado(item) {
      if (item.estado_pago === item.total_v) {
        Vue.$toast.success("actualizando información...");
        axios
          .post("/cambiar_estado_ventas/" + item.id)
          .then((res) => {
            this.listar();
          })
          .catch((error) => {
            swal("ERROR", "comprobar conexión", "info");
          });
      } else {
        swal({
          text: "el monto aún no se ha completado",
          icon: "error",
          button: "aceptar",
          dangerMode: true,
        });
      }
    },
    estado_pago_edit(item) {
      swal("agregar monto", {
        content: "input",
        buttons: "agregar",
      }).then((value) => {
        if (value > 0) {
          //**** AGREGAR MONTO ****
          Vue.$toast.success("actualizando información...");
          const params = {
            monto: parseFloat(value) + parseFloat(item.estado_pago),
          };
          axios
            .post("/estado_pago/" + item.id, params)
            .then((res) => {
              this.listar();
            })
            .catch((error) => {
              swal("ERROR", "comprobar conexión", "info");
            });
          //***** FIN *****
        } else {
          Vue.$toast.error("monto incorrecto");
        }
      });
    },
    buscar() {
      if (this.search.trim() === "" || this.search <= 0) {
        Vue.$toast.error("campo vacío");
      } else {
        this.loading_table = true;
        let url =
          "/api/search_ventas/" +
          this.search +
          "/" +
          this.user_sucursal +
          "/0?page";
        axios.get(url).then((res) => {
          this.ventas = res.data.ventas.data;
          this.pagination = res.data.paginate;
          this.loading_table = false;
        });
      }
    },
    anular_factura_items(item, index) {
      swal({
        text: "¿estás seguro?",
        icon: "error",
        buttons: ["no", "sí"],
        dangerMode: true,
      }).then((willDelete) => {
        if (willDelete) {
          Vue.$toast.info("actualizando datos...");
          let url = `/api/listdetalles/${item.cod_sucursal}/${this.user_sucursal}`;
          axios
            .get(url)
            .then((res) => {
              this.detalles = res.data;
              let i = 0;
              for (i = 0; i < this.detalles.length; i++) {
                const params = {
                  sucursal: this.user_sucursal,
                  barra: this.detalles[i].barra,
                  cantidad: this.detalles[i].cantidad,
                };
                axios
                  .post("/subir_stock_venta/" + params.barra, params)
                  .then((res) => {
                    Vue.$toast.info("producto actualizado");
                  });
              }
              this.anular_factura(item, index);
            })
            .catch((error) => {
              swal("ERROR", "comprobar conexión", "info");
            });
        }
      });
    },
  },
  computed: {
    total_venta() {
      return this.detalles.reduce((total, item) => {
        return total + item.precio * item.cantidad;
      }, 0);
    },
    total_descuento() {
      return this.detalles.reduce((total, item) => {
        return parseFloat(total) + parseFloat(item.descuento);
      }, 0);
    },
    total_general() {
      return this.detalles.reduce((total, item) => {
        return total + item.precio * item.cantidad - item.descuento;
      }, 0);
    },
  },
};
</script>