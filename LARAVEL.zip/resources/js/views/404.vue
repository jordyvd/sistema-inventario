<template>
  <div class="container pdd-30">
    <div class="alert alert-light" role="alert">
      <h4 class="alert-heading icon-error centrar">
        <i class="far fa-frown-open"></i>
      </h4>
      <p class="centrar text-grande">
        <b>ERROR 404</b>
      </p>
      <hr />
      <p class="mb-0 centrar">esta sección no esta disponible</p>
    </div>
  </div>
</template>