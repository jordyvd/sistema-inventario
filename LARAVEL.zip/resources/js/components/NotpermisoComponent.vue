<template>
  <div class="alert alert-light" role="alert">
    <h4 class="alert-heading icon-error centrar">
      <i class="far fa-frown-open"></i>
    </h4>
    <p class="centrar">
      <b>{{user_name}}</b>, no cuentas con permisos para acceder a esta sección
    </p>
    <hr />
    <p class="mb-0 centrar">si requieres de esta sección, contactate con administación</p>
  </div>
</template>