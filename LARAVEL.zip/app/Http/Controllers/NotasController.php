<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Proveedor;
use App\detalle_notas;
use App\almacen;
use App\Notas;
use App\product;
use App\Movimientos;
use Illuminate\Support\Facades\DB;

class NotasController extends Controller
{
   public function crearempresa(Request $request){
      $proveedor = new proveedor;
      $proveedor->ruc = $request->ruc;
      $proveedor->nombre = $request->nombre;
      $proveedor->save();
   }
   public function listarproveedor(){
      $proveedor = proveedor::orderBy('id','DESC')->paginate(8);
      return [
         'paginate' => [
              'total'        => $proveedor->total(),
              'current_page' => $proveedor->currentPage(),
              'per_page'     => $proveedor->perPage(),
              'last_page'    => $proveedor->lastPage(),
              'from'         => $proveedor->firstItem(),
              'to'           => $proveedor->lastPage(),
         ],
         'proveedor' => $proveedor
      ];
   }
   public function deleteproveedor($id){
      $proveedor = proveedor::find($id);
      $proveedor->delete();
   }
   public function buscarproveedor($ruc){
      return proveedor::where('ruc',$ruc)->first();
   }
   public function agregar_nota(Request $request){
      $nota = new Notas;
      $nota->codigo_nota = $request->cod_nota;
      $nota->nro = $request->nro;
      $nota->sucursal = $request->sucursal;
      $nota->total = $request->total;
      $nota->ruc_provee = $request->ruc;
      $nota->empresa = $request->empresa;
      $nota->fecha = date('Y-m-d');
      $nota->estado = '0';
      $nota->save();
   }
   public function agregar_detalle_nota(Request $request){
      $detalle = new detalle_notas;
      $detalle->barra_nota = $request->barra;
      $detalle->precio_com = $request->precio;
      $detalle->descuento = $request->descuento;
      $detalle->cantidad = $request->cantidad;
      $detalle->cod_nota = $request->cod_nota;
      $detalle->save();
   }
   public function codigo_generado($sucursal){
      return Notas::where('sucursal',$sucursal)->max('nro');
   }
   public function listar_pedidos($sucursal,$fecha){
      if($fecha === "1"){
         $notas = Notas::where('sucursal',$sucursal)
         ->where('nro','>',0)
         ->orderBy('id','DESC')->paginate(7);
      }
      else{
         $notas = Notas::where('sucursal',$sucursal)
         ->where('fecha',$fecha)
         ->where('nro','>',0)
         ->orderBy('id','DESC')->paginate(7);
      }
      return [
         'paginate' => [
              'total'        => $notas->total(),
              'current_page' => $notas->currentPage(),
              'per_page'     => $notas->perPage(),
              'last_page'    => $notas->lastPage(),
              'from'         => $notas->firstItem(),
              'to'           => $notas->lastPage(),
         ],
         'notas' => $notas
      ];
   }
   public function buscar_num_pedido($search,$sucursal){
      $notas = Notas::where('codigo_nota','like','%'.$search.'%')
       ->where('sucursal',$sucursal)
       ->orderBy('id','DESC')->paginate(8);
       return [
         'paginate' => [
              'total'        => $notas->total(),
            //   'current_page' => $notas->currentPage(),
              'per_page'     => $notas->perPage(),
              'last_page'    => $notas->lastPage(),
              'from'         => $notas->firstItem(),
              'to'           => $notas->lastPage(),
         ],
         'notas' => $notas
      ];
   }
   public function detallesnotas_pedido($codigo)
   {
      return detalle_notas::select('products.barra','products.nompro','products.marca','detalle_notas.precio_com','detalle_notas.cantidad','detalle_notas.descuento')
      ->join('products','detalle_notas.barra_nota','products.barra')
      ->where('detalle_notas.cod_nota',$codigo)
      ->get();
   }
   public function cambiarestado_nota(Request $request,$id)
   {
      $notas = Notas::find($id);
      $notas->estado = "1";
      $notas->save();
   }
   public function subirstock_nota(Request $request, $barra)
   {
      $almacen = almacen::where('barra_almacen',$barra)
      ->where('sucursal',$request->sucursal)->first();
      // **** PRODUCTO GENERAL ****
      $product = product::where('barra',$barra)->first();
       // **** PRODUCTO GENERAL ****
      $stock = almacen::find($almacen->id);
      $stock->stock_almacen = intval($almacen->stock_almacen) + intval($request->cantidad);
      $stock->save(); 
      $precio_comp = product::find($product->id);
      $precio_comp->precio = $request->precio;
      $precio_comp->save();
       //movimiento
        $movimiento = new Movimientos;
        $movimiento->barra_mov = $barra;
        $movimiento->precio = $request->precio;
        $movimiento->condicion = "entrada";
        $movimiento->fecha = date('Y-m-d');
        $movimiento->detalle = "comprado";
        $movimiento->tipo = "compra";
        $movimiento->cantidad = $request->cantidad;
        $movimiento->sucursal = $request->sucursal;
        $movimiento->save();
   }
   public function eliminarnota($codigo)
   {
      $notas = Notas::where('codigo_nota',$codigo);
      $notas->delete(); 
      $detalle = detalle_notas::where('cod_nota',$codigo)->delete();
   }
   public function bajarstock_nota(Request $request,$barra)
   {
      $almacen = almacen::where('barra_almacen',$barra)
      ->where('sucursal',$request->sucursal)->first();
      $stock = almacen::find($almacen->id);
      $stock->stock_almacen = intval($almacen->stock_almacen) - intval($request->cantidad);
      $stock->save(); 
      $movimiento = new Movimientos;
      $movimiento->barra_mov = $barra;
      $movimiento->precio = $request->precio;
      $movimiento->condicion = "salida";
      $movimiento->fecha = date('Y-m-d');
      $movimiento->detalle = "anulado";
      $movimiento->tipo = "compra";
      $movimiento->cantidad = $request->cantidad;
      $movimiento->sucursal = $request->sucursal;
      $movimiento->save();
   }
}
