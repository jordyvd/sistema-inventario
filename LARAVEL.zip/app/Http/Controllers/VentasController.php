<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\ventas;
use App\almacen;
use App\detalle_venta;
use App\cliente;
use App\Movimientos;

class VentasController extends Controller
{
    public function nuevaventa($sucursal){
        return ventas::where('sucursal',$sucursal)->max('nrof');
    }
    public function listcreditos(Request $request, $sucursal,$fecha,$desde){
        if($fecha === "1" && $desde === "1"){
           $fecha = date('Y-m-d');
           $desde = date('Y-m-d');
        }
        $ventas = ventas::where('sucursal',$sucursal)
        ->whereBetween('fecha',[$desde,$fecha])
        ->where('nrof','>',0)
        ->where('estado','=','0')
        ->orderBy('id','DESC')
        ->paginate(12);
        return [
            'paginate' => [
                 'total'        => $ventas->total(),
                 'current_page' => $ventas->currentPage(),
                 'per_page'     => $ventas->perPage(),
                 'last_page'    => $ventas->lastPage(),
                 'from'         => $ventas->firstItem(),
                 'to'           => $ventas->lastPage(),
            ],
            'ventas' => $ventas
         ];
    }
    public function listventas(Request $request, $sucursal,$fecha,$desde,$estado){
        if($fecha === "1" && $desde === "1"){
           $fecha = date('Y-m-d');
           $desde = date('Y-m-d');
        }
        $ventas = ventas::where('sucursal',$sucursal)
        ->whereBetween('fecha',[$desde,$fecha])
        ->where('nrof','>',0)
        ->where('estado','!=','0')
        ->orderBy('id','DESC')
        ->paginate(12);
        return [
            'paginate' => [
                 'total'        => $ventas->total(),
                 'current_page' => $ventas->currentPage(),
                 'per_page'     => $ventas->perPage(),
                 'last_page'    => $ventas->lastPage(),
                 'from'         => $ventas->firstItem(),
                 'to'           => $ventas->lastPage(),
            ],
            'ventas' => $ventas
         ];
    }
    public function listdetalles($nrof,$sucursal){
        return detalle_venta::select('detalle_venta.id','products.barra','products.nompro','detalle_venta.precio','detalle_venta.descuento','detalle_venta.cantidad')
        ->join('products','detalle_venta.barra_detalles','products.barra')
        ->where('detalle_venta.sucursal',$sucursal)
        ->where('detalle_venta.nrof',$nrof)
        ->get();
        
    }
    public function eliminarP($id){
        $detalle = detalle_venta::where('id',$id)
        ->delete();
    }
    public function search_ventas($search,$sucursal,$estado){
        if($estado === "1"){
            $ventas = ventas::where('sucursal',$sucursal)
            ->where('nrof','like','%'.$search.'%')
            ->where('estado','!=','0')
            ->orderBy('id','DESC')
            ->paginate(1);
        }else{
            $ventas = ventas::where('sucursal',$sucursal)
            ->where('nrof','like','%'.$search.'%')
            ->where('estado',$estado)
            ->orderBy('id','DESC')
            ->paginate(1);
        }
        return [
            'paginate' => [
                 'total'        => $ventas->total(),
                //  'current_page' => $ventas->currentPage(),
                 'per_page'     => $ventas->perPage(),
                 'last_page'    => $ventas->lastPage(),
                 'from'         => $ventas->firstItem(),
                 'to'           => $ventas->lastPage(),
            ],
            'ventas' => $ventas
         ];
    }
    public function modificaracumulado(Request $request,$id){
        $venta = ventas::find($id);
        $venta->estado_pago = $request->acumulado;
        $venta->save();
    }
    public function generar_venta(Request $request){
        $venta = new ventas;
        $venta->nrof = $request->nrof;
        $venta->estado = $request->estado;
        $venta->estado_pago = '0'; 
        $venta->tipo_v = $request->tipo_v;
        $venta->total_v = $request->total_v;
        $venta->total_ganancia = $request->total_ganancia;
        $venta->ruc_dni_v = $request->ruc_dni;
        $venta->nombre_cliente = $request->nom_cliente;
        $venta->sucursal = $request->sucursal;
        $venta->cod_sucursal = $request->cod_sucursal;
        $venta->usuario = $request->usuario;
        $venta->fecha = date('Y-m-d');
        $venta->save();
        return back();
    }
    public function detalle_venta(Request $request){
        //guardar detalles
        $detalle = new detalle_venta;
        $detalle->barra_detalles = $request->barra;
        $detalle->cantidad = $request->cantidad;
        $detalle->precio = $request->precio;
        $detalle->descuento = $request->descuento;
        $detalle->nrof = $request->nrof;
        $detalle->sucursal = $request->sucursal;
        $detalle->save();
        //bajar stock
        $almacen = almacen::where('barra_almacen',$request->barra)
        ->where('sucursal',$request->sucursal)->first();
        $stock = almacen::find($almacen->id);
        $stock->stock_almacen = intval($almacen->stock_almacen) - intval($request->cantidad);
        $stock->save(); 
        //movimiento
        $movimiento = new Movimientos;
        $movimiento->barra_mov = $request->barra;
        $movimiento->precio = $request->precio;
        $movimiento->condicion = "salida";
        $movimiento->fecha = date('Y-m-d');
        $movimiento->detalle = "vendido";
        $movimiento->tipo = "venta";
        $movimiento->cantidad = $request->cantidad;
        $movimiento->sucursal = $request->sucursal;
        $movimiento->save();
    }
    public function anularfactura($id,$nrof,$sucursal){
        $venta = ventas::find($id);
        $venta->delete();
        $detalle = detalle_venta::where('nrof',$nrof)->where('sucursal',$sucursal)
        ->delete();
    }
    public function estado_pago(Request $request, $id){
        $ventas = ventas::find($id);
        $ventas->estado_pago = $request->monto;
        $ventas->save();
    }
    public function cambiar_estado(Request $request,$id){
        $ventas = ventas::find($id);
        $ventas->estado = 'credito';
        $ventas->save();
    }
    public function subir_stock_venta(Request $request,$barra){
        $almacen = almacen::where('barra_almacen',$request->barra)
        ->where('sucursal',$request->sucursal)->first();
        $stock = almacen::find($almacen->id);
        $stock->stock_almacen = intval($almacen->stock_almacen) + intval($request->cantidad);
        $stock->save();
        //movimiento
        $movimiento = new Movimientos;
        $movimiento->barra_mov = $request->barra;
        $movimiento->precio = $almacen->precio_venta;
        $movimiento->condicion = "entrada";
        $movimiento->fecha = date('Y-m-d');
        $movimiento->detalle = "anulado";
        $movimiento->tipo = "venta";
        $movimiento->cantidad = $request->cantidad;
        $movimiento->sucursal = $request->sucursal;
        $movimiento->save();
    }
    public function buscarclienteventa($cliente){
        return cliente::where('ruc_dni',$cliente)->first();
    }
}
