function zeroPad(num, numZeros) {
    var n = Math.abs(num);
    var zeros = Math.max(0, numZeros - Math.floor(n).toString().length);
    var zeroString = Math.pow(10, zeros).toString().substr(1);
    if (num < 0) {
        zeroString = '-' + zeroString;
    }

    return zeroString + n;
}

// ***** solo numero *****
$(".solonumero").keydown(function (event) {
    //alert(event.keyCode);
    if ((event.keyCode < 48 || event.keyCode > 57) && (event.keyCode < 96 || event.keyCode > 105) && event.keyCode !== 190 && event.keyCode !== 110 && event.keyCode !== 8 && event.keyCode !== 9) {
        return false;
    }
});

$(document).keypress(function (e) {
    if (e.charCode == 61) {
        document.getElementById("nuevaventa").click();
    }
});
// $(document).keypress(function (e) {
//     if (e.charCode == 119) {
//         document.getElementById("producto_crud").click();
//     }
// });
$(document).keypress(function (e) {
    if (e.charCode == 59) {
        document.getElementById("inventario_click").click();
    }
});


